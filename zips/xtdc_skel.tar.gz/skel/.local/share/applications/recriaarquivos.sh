#!/bin/bash
#
#######################
#    ^...^  `^...^´   #
#   / o,o \ / O,O \   #
#   |):::(| |):::(|   #
# ====" "=====" "==== #
#         TdC         #
#      1998-2026      #
#######################
#
# Toca das Corujas
# Códigos Binários,
# Funções de Onda e
# Teoria do Orbital Molecular Inc.
# Unidade Barão Geraldo CX
#
# 2026_11_13_19_31_03

 

shopt -s nullglob
BASE_DIR="."

# Executa uma função dentro de todas as pastas, incluindo a pasta atual
executar_em_todas_as_pastas() {
    local funcao="$1"

    while IFS= read -r -d '' pasta; do
        echo "Processando: $pasta"
        (
            cd -- "$pasta" || exit 1
            "$funcao"
        )
    done < <(find "$BASE_DIR" -type d -print0)
}

# Renomeia os arquivos .svg da pasta atual para .txt
renomear_para_txt_pasta() {
    local arquivo novo_nome

    for arquivo in *.svg; do
        [ -f "$arquivo" ] || continue

        novo_nome="${arquivo%.svg}.txt"

        if [ -e "$novo_nome" ]; then
            echo "Ignorado: $novo_nome já existe"
        else
            mv -- "$arquivo" "$novo_nome"
        fi
    done
}

renomear_para_txt() {
    executar_em_todas_as_pastas renomear_para_txt_pasta
}

# Cria um tudo.txt em cada pasta com os arquivos .txt daquela pasta
criar_tudo_txt_pasta() {
    local arquivo

    : > tudo.txt

    for arquivo in *.txt; do
        [ -f "$arquivo" ] || continue
        [ "$arquivo" = "tudo.txt" ] && continue

        printf '=== ARQUIVO: %s ===\n' "$arquivo" >> tudo.txt
        cat -- "$arquivo" >> tudo.txt
        printf '\n\n' >> tudo.txt
    done
}

criar_tudo_txt() {
    executar_em_todas_as_pastas criar_tudo_txt_pasta
}

# Recria os arquivos .txt usando o tudo.txt da pasta atual
recriar_arquivos_pasta() {
    local nome_arquivo=""
    local conteudo=""
    local linha

    [ -f "tudo.txt" ] || return 0

    while IFS= read -r linha || [ -n "$linha" ]; do
        if [[ "$linha" == "=== ARQUIVO: "*" ===" ]]; then

            # Salva o arquivo anterior
            if [ -n "$nome_arquivo" ]; then
                printf '%s' "$conteudo" > "$nome_arquivo"
            fi

            nome_arquivo="${linha#=== ARQUIVO: }"
            nome_arquivo="${nome_arquivo% ===}"
            conteudo=""
        else
            conteudo+="$linha"$'\n'
        fi
    done < tudo.txt

    # Salva o último arquivo
    if [ -n "$nome_arquivo" ]; then
        printf '%s' "$conteudo" > "$nome_arquivo"
    fi
}

recriar_arquivos() {
    executar_em_todas_as_pastas recriar_arquivos_pasta
}

# Renomeia os arquivos .txt da pasta atual para .svg
renomear_para_desktop_pasta() {
    local arquivo novo_nome

    for arquivo in *.txt; do
        [ -f "$arquivo" ] || continue
        [ "$arquivo" = "tudo.txt" ] && continue

        novo_nome="${arquivo%.txt}.svg"

        if [ -e "$novo_nome" ]; then
            echo "Ignorado: $novo_nome já existe"
        else
            mv -- "$arquivo" "$novo_nome"
            chmod 644 -- "$novo_nome"
        fi
    done
}

renomear_para_desktop() {
    executar_em_todas_as_pastas renomear_para_desktop_pasta
}

# Menu principal
echo "Selecione a opção:"
echo "1 - Renomear arquivos .svg para .txt"
echo "2 - Criar tudo.txt em todas as pastas"
echo "3 - Recriar arquivos a partir de tudo.txt"
echo "4 - Renomear arquivos .txt para .svg"
echo "5 - Executar todas as etapas"
read -r -p "Opção: " opcao

case "$opcao" in
    1)
        renomear_para_txt
        ;;
    2)
        criar_tudo_txt
        ;;
    3)
        recriar_arquivos
        ;;
    4)
        renomear_para_desktop
        ;;
    5)
        renomear_para_txt
        criar_tudo_txt
        recriar_arquivos
        renomear_para_desktop
        ;;
    *)
        echo "Opção inválida"
        exit 1
        ;;
esac

echo "Operação concluída."
